using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class FighterTeam : MonoBehaviour
{
   [SerializeField] List<Fighter> fighters;
   
   
   public List<Fighter> Fighters {
       get{
           return fighters;
       }
   }

   private void Start ()
   {
       foreach( var fighter in fighters)
       {
           fighter.Init();
       }
   }

   public Fighter GetHealthyFighter()
   {
    return fighters.Where(x => x.HP >0).FirstOrDefault();//looping throung the team list to find the first non feighted fighter
       
   }

   public void AddFighter(Fighter newFighter)
   {
       if(fighters.Count<6)
       {
           fighters.Add(newFighter);
       }
       else
       {
         //can only select 6 for now
       }
   }
}
