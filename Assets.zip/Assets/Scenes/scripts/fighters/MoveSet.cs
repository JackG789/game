using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "move", menuName = "fighters/create new move")]

public class MoveSet : ScriptableObject//setting up a scriptable object for all diffrent moves avaliable to each fighter
{
  [SerializeField] string name;


  [TextArea]
  [SerializeField] string description;

  [SerializeField] FighterType type;  
  [SerializeField] int damage;
  [SerializeField] int accuracy;
  [SerializeField] int energy;
  [SerializeField] bool canBlock;
  [SerializeField] bool isSpecial;

    public string Name{
       get{ return name;}
    }
    public string Description{
       get{ return description;}
    }
    public FighterType Type{
       get{return type;}
    }
    public int Damage{
       get{ return damage;}
    }
    public int Accuracy{
       get{ return accuracy;}
    }
    public int Energy{
       get{ return energy;}
    }
    public bool CanBlock {
       get{return canBlock;}
    }
    public bool IsSpecial{
       get{return isSpecial;

       }
    }
   

}
