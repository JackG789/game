using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move //stat changes to the moves inside of the game
{
    public MoveSet Set{get;set;} //pulling the properties from the moveSet using the getter and setting up the setter

    public int Energy{get;set;}

    public Move(MoveSet eSet) 
    {
        Set = eSet;
        Energy = eSet.Energy;
        
    }
}
