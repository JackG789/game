using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "fighters", menuName = "fighters/create new Fighters")] // creating a menu option to be able to create new fighters inside of unity


public class BasicFighter : ScriptableObject //the fihgters information
{
    [SerializeField] string name;

    [TextArea]
    [SerializeField] string description;

    [SerializeField] Sprite standingSpritePlayer;
    [SerializeField] Sprite standingSpriteOpponent;

    [SerializeField] FighterType type;

    [SerializeField] int maxHp;//base stats of the fighters 
    [SerializeField] int attack;
    [SerializeField] int defense;
    [SerializeField] int spAttack;
    [SerializeField] int spDefence;
    [SerializeField] int speed;
    [SerializeField] int expYield;


    [SerializeField] bool isSpecial;


   [SerializeField] List<LearnableMove> learnableMoves; //creating the list for the learnable moves using the list function

    public string Name{
       get{ return name;}
    }
    public string Description{
       get{ return description;}
    }
    public Sprite StandingSpritePlayer{
       get{ return standingSpritePlayer;}
    } 
    public Sprite StandingSpriteOpponent{
       get{ return standingSpriteOpponent;}
    }
    public FighterType Type{
       get{return type;}
    }
    public int MaxHp{
       get{ return maxHp;}
    }
    public int Attack{
       get{ return attack;}
    }
    public int Defense{
       get{ return defense;}
    }
    public int SpAttack{
       get{ return spAttack;}
    }
    public int SpDefence{
       get{ return spDefence;}
    }
    public int Speed{
       get{ return speed;}
    }
    public bool IsSpecial{
       get{return isSpecial;}

       }
     public int ExpYield => expYield;

   public List<LearnableMove> LearnableMoves{
      get{return learnableMoves;}

   }

}


[System.Serializable]

public class LearnableMove
{
   [SerializeField] MoveSet moveSet;
   [SerializeField] int level;

   public MoveSet Set{
      get{ return moveSet;}
   }

   public int Level{
      get{return level;}
   }
}



public enum FighterType //enumerator for defining each fighters type
{
    Basic,
    Fire,
    Water,
    Grass,
}


public class TypeChart//using a type chart to store the types so that it could be scalable with more elemental moves/ fighters in the future
 {
    static float[][] chart =
    {
       new float[] {1f,1f,1f,1f},//basic
       new float[] {1f,0.5f,0.5f,2f},//fire
       new float[] {1f,2f,0.5f,0.5f},//water
       new float[] {1f,0.5f,2f,0.5f}//grass
    };

    public static float GetEffectiveness(FighterType attackType, FighterType defenseType)
{
   if (attackType == FighterType.Basic || defenseType == FighterType.Basic)
   {
      return 1;
   }

   int row =(int)attackType -1;
   int col = (int)defenseType -1;

   return chart[row][col];
}
 }


 

 
