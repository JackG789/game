using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

[System.Serializable]

public class Fighter //calculating the individual fighters stats based on the Level
{
    
    [SerializeField]  BasicFighter _base;
    [SerializeField]  int level;

    public BasicFighter Base {
        get{
            return _base;
        }
    }
    public int Level {
        get{
            return level;
        }
    }
    public int Exp{get;set;}

    public int HP{get;set;}

    public List<Move> Moves {get;set;}


    public void Init() //creating the instance of the fighter
    {


        HP = MaxHp;

        Moves = new List<Move>();

        foreach(var move in Base.LearnableMoves)//checking to see if the fighter is a high enough Level to lear the move 
        {
            if(move.Level <= Level)
            {
                Moves.Add(new Move(move.Set));

                if(Moves.Count >=4)
                {
                    break;
                }
            }
        }

        Exp = Level*Level*Level;
    }

    public bool CheckForLevelUp()
    {
        if(Exp>((level+2)*(Level+1)*(Level+1))){
            ++level;
            return true;
        }
        return false;
    }

    public LearnableMove GetLearnableMoveAtCurrentLevel()
    {
        return Base.LearnableMoves.Where(x=>x.Level == level).FirstOrDefault();
    }

    public void LearnMove(LearnableMove moveToLearn)
    {
        if(Moves.Count >4)
        {return;}
        Moves.Add(new Move(moveToLearn.Set));
    }
    public int Attack{
        get{return Mathf.FloorToInt((Base.Attack*Level)/100f)+5;}//calculates the attack stat at the current Level using a simmilar formula to that of the pokemon games 
    }
    public int Defense{
        get{return Mathf.FloorToInt((Base.Defense*Level)/100f)+5;}
    }
    public int SpAttack{
        get{return Mathf.FloorToInt((Base.SpAttack*Level)/100f)+5;}
    }
    public int SpDefence{
        get{return Mathf.FloorToInt((Base.SpDefence*Level)/100f)+5;}
    }
    public int Speed{
        get{return Mathf.FloorToInt((Base.Speed*Level)/100f)+5;}
    }
    public int MaxHp{
        get{return Mathf.FloorToInt((Base.MaxHp*Level)/100f)+10;}
    }
    


    public DamageInfo TakeDamage(Move move, Fighter attacker)//calcualting the damage based on a random range of 85% pwer to 100% taking into account the attack and defence sats of both fighters
    {
       
        float critical =1f;
        if(Random.value * 100f<=6.25f )//critical damage chance 
        {
            critical =2f;
        }
      
        float type = TypeChart.GetEffectiveness(move.Set.Type, this.Base.Type);
       

        var damageInfo = new DamageInfo()
        {
            TypeEffect = type,
            Critical = critical,
            Fainted = false
        };

        float attack = (this.Base.IsSpecial)? attacker.SpAttack:attacker.Attack;
        float defence = (this.Base.IsSpecial)? attacker.SpDefence:attacker.Defense;


        float modifiers = Random.Range(0.85f,1f)*type*critical;
        float a = (2* attacker.Level +10)/250f;

        float d = a * move.Set.Damage *((float)attack / defence) +2;//come back to and update power one typing is sorted 
        int damage = Mathf.FloorToInt(d*modifiers);

       

        HP -= damage;
        if(HP <= 0)
        {
            HP =0;
            damageInfo.Fainted = true;
        }

        return damageInfo;
    }


    //public Move GetEnemyMoveRandom() //temp til ai is done
  //  {
    //    int ran = Random.Range(0,Moves.Count);
     //   return Moves[ran];//return a move at the index of the move position 
   // }


    public Move GetEnemyMove(BattleFighter enemyFighter, BattleFighter playerFighter) //AI for calculating the best move
    {        
       
        int ran = Random.Range(0,Moves.Count);
        if(enemyFighter.Fighter.HP<(enemyFighter.Fighter.HP/2.5))//if your health is in critical range
        {
            if(enemyFighter.Fighter.Base.Speed>playerFighter.Fighter.Base.Speed)//if you outspeed 
            {
                for(int i =0; i<Moves.Count;i++)
                {
                if((Moves[i].Set.CanBlock) == (Moves[i].Set.CanBlock==true))//checking to see if there is a block move that could be used
                {
                   if(Moves[i].Set.Energy>0){
                        return Moves[i];//return the block move if all conditions are met 
                   }
                }
                }
            }
        }
        else if(playerFighter.Fighter.HP<(playerFighter.Fighter.HP/2.5))//is the enemy in critical range
        {
            if(enemyFighter.Fighter.Base.Speed>playerFighter.Fighter.Base.Speed)//if you outspeed 
            {
                 for(int i =0; i<Moves.Count;i++)
                 {
                    if((Moves[i].Set.Accuracy>Moves[i+1].Set.Accuracy)&&(Moves[i].Set.Damage >0))//use the highest accuracy move that deals damage
                    {
                        if(Moves[i].Set.Energy>0){//check for energy 
                            return Moves[i];
                        }
                    }
                 }
            }
        }
        else{
        for(int i =0; i<Moves.Count;i++)
                 {
                    if(TypeChart.GetEffectiveness(Moves[i].Set.Type, playerFighter.Fighter.Base.Type)>1)//check to see if you have any supereffective moves to use them first
                    {
                        if(Moves[i].Set.Energy>0){
                            return Moves[i];
                        }
                     }
                 }
        }
        return Moves[ran];// use a random move if no other condition is met
        
        
    }
}

public class DamageInfo
{
    public bool Fainted {get;set;}
    public float Critical  {get;set;}
    public float TypeEffect {get;set;}
}
