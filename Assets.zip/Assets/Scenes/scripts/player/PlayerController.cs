using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed;
    public LayerMask solidLayer;
    public LayerMask shadowLayer;

    public event Action OnEncountered;

    private bool isMoving;
    private Vector2 input;
    
    private Animator animator;
    
    private void Awake(){

        animator= GetComponent<Animator>();
    }

    // Update is called once per frame
    public void HandleUpdate()
    {
        if(!isMoving){
            
        input.x=Input.GetAxisRaw("Horizontal");
        input.y=Input.GetAxisRaw("Vertical");

            if(input != Vector2.zero){

                animator.SetFloat("moveX",input.x);
                animator.SetFloat("moveY",input.y);


                var targetPos = transform.position;
                targetPos.x += input.x;
                targetPos.y += input.y;

                if(isPassiable(targetPos))
                    StartCoroutine(Move(targetPos));
            }
        }
        animator.SetBool("isMoving",isMoving);
    }

    IEnumerator Move(Vector3 targetPos)//moving and checking is the movement is effected by any other actions
    {
        isMoving = true;
        while((targetPos - transform.position).sqrMagnitude >Mathf.Epsilon){
            transform.position = Vector3.MoveTowards(transform.position,targetPos, moveSpeed * Time.deltaTime);
            yield return null;
        }
        transform.position = targetPos;
        isMoving = false;

        CheckforShadowEncounters();
    }

    private bool isPassiable(Vector3 targetPos)//wherether or not there is an object withing the area of the players path 
    {

        if(Physics2D.OverlapCircle(targetPos,0.1f,solidLayer) != null){
            return false;
        }
        return true;
    }


    private void CheckforShadowEncounters()//checking to see if in a shadow zone to enable random encounters
    {
         if(Physics2D.OverlapCircle(transform.position,0.2f,shadowLayer) != null)
            {
               if( UnityEngine.Random.Range(1,101) <=10)
               {
                animator.SetBool("isMoving", false);
                OnEncountered();
                 
               }
             }
    }
}
