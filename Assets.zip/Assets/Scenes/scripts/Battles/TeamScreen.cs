using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TeamScreen : MonoBehaviour
{
  [SerializeField] Text messageText;

  TeamMemberUI[] teamSlots;
  List<Fighter> fighters;

    public TeamMemberUI[] TeamSlots{
        get{return teamSlots;}
    }

  public void Init()//initilising the ui screen to show the team members
  {
      teamSlots = GetComponentsInChildren<TeamMemberUI>(true);
  }

  public void SetTeamData(List<Fighter> fighters)//making sure only the correnct number of team slots gets shown
  {
      this.fighters = fighters;
      for(int i=0; i<teamSlots.Length; i++)
      {
          if(i<fighters.Count) 
          {
            teamSlots[i].gameObject.SetActive(true);
              teamSlots[i].SetData(fighters[i]);
          }
          else
          {
            teamSlots[i].gameObject.SetActive(false);
          }
      }

      messageText.text ="Choose Your Next Fighter";
  }

  public void UpdateMemberSelection(int selectedMember)
  {
      for(int i =0; i<fighters.Count; i++)
      {
          if(i == selectedMember)
          {
              teamSlots[i].SetSelected(true);
          }
          else
          {
              teamSlots[i].SetSelected(false);
          }
      }
  }

  public void SetMessageText(string message)
  {
      messageText.text = message;
  }
   public void SetTeamDataRedo(List<Fighter> fighters)//making sure only the correnct number of team slots gets shown
  {
      this.fighters = fighters;
      for(int i=0; i<teamSlots.Length; i++)
      {
          if(i<fighters.Count) 
          {
            
              teamSlots[i].SetData(fighters[i]);
          }
      }
  }
}
