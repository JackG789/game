using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TeamMemberUI : MonoBehaviour
{
 [SerializeField] Text playerFighterNameText;
 [SerializeField] Text playerFighterLvelText;
 [SerializeField] HealthBar HpBar;
 [SerializeField] Color highlightedColor;


  Fighter _fighter;//creating a local instance of the fighter object

 public void SetData(Fighter fighter)
 {
     _fighter = fighter;
     playerFighterNameText.text = fighter.Base.Name; //get the name of the fighter for the hud
     playerFighterLvelText.text = "Lvl " + fighter.Level; // get the level of the fighter for the hud
     HpBar.SetHP((float)fighter.HP/fighter.MaxHp);//calculating the scale for the hp bar 
 }
public void SetHpData(Fighter fighter)
{
HpBar.SetHP((float)fighter.HP/fighter.MaxHp);
}
 public void SetSelected(bool selected)
 {
     if(selected)
     {
         playerFighterNameText.color =highlightedColor;
     }
     else
     {
         playerFighterNameText.color = Color.black;
     }
 }
 
}
