using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBar : MonoBehaviour
{
    [SerializeField] GameObject health;

    
    public void SetHP(float hpNormalized)
    {
        health.transform.localScale = new Vector3(hpNormalized,1f);
    }

    public IEnumerator SetHPSm(float newHp)//make the hp go down smothly 
    {

        float currentHp = health.transform.localScale.x;
        float changeAmount = currentHp - newHp;
      

        while(currentHp - newHp > Mathf.Epsilon )
          {
                currentHp -= changeAmount * Time.deltaTime;
                health.transform.localScale = new Vector3(currentHp,1f);
                yield return null;
            }
            health.transform.localScale = new Vector3(newHp,1f);
        
    }
}
