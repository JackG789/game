using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleDialogBox : MonoBehaviour
{
  [SerializeField] Text dialogText;

  [SerializeField] int letterPSecond;

  [SerializeField] GameObject actionSelector;
  [SerializeField] GameObject moveSelector;
  [SerializeField] GameObject moveInfo;
  [SerializeField] GameObject CatchSelector;

  [SerializeField] Color highlightedColor;

  [SerializeField] List<Text> catchTexts;
  [SerializeField] List<Text> actionTexts;
  [SerializeField] List<Text> moveTexts;

  [SerializeField] Text energyText;
  [SerializeField] Text typeText;  
//  [SerializeField] Text moveDiscription;


  public void SetDialog(string dialog)
  {
  dialogText.text = dialog;
  }

  public IEnumerator TypeDialog(string dialog)//making the text slowly appear by looping through the text
  {
    dialogText.text="";
    foreach(var letter in dialog.ToCharArray())
    {
      dialogText.text += letter;
      yield return new WaitForSeconds(1f/letterPSecond);
    }
    yield return new WaitForSeconds(1f);
  }

  public void EnabelDialogText(bool enabled)
  {
    dialogText.enabled = enabled;
  }
  public void EnabelActionSelect(bool enabled)
  {
    actionSelector.SetActive(enabled);
  }
  public void EnabelMoveSelect(bool enabled)
  {
    moveSelector.SetActive(enabled);
    moveInfo.SetActive(enabled);
  }
  public void EnabelCatchSelect(bool enabled)
  {
    CatchSelector.SetActive(enabled);
    
  }
  
  public void UpdateActionSelection(int selectedAction)//update the hud with the selection 
  {
    for( int i=0; i<actionTexts.Count; ++i)
    {
      if (i == selectedAction)
      {
         actionTexts[i].color = highlightedColor;
      }
      else
      {
        actionTexts[i].color = Color.black;
      }
    }
  }

  public void SetMoveNames(List<Move> moves)
  {
    for( int i= 0;i<moveTexts.Count; ++i )
    {
      if(i<moves.Count)
      {
        moveTexts[i].text = moves[i].Set.Name;
      }
      else
      {
        moveTexts[i].text = "-";
      }
    }
  }

  public void UpdateMoveSelection(int selectedMove,Move move)//update the hud with the selection 
  {
    for( int i=0; i<moveTexts.Count; ++i)
    {
      if (i == selectedMove)
      {
         moveTexts[i].color = highlightedColor;
      }
      else
      {
        moveTexts[i].color = Color.black;
      }
    }

    energyText.text = $"Energy {move.Energy}/{move.Set.Energy}";
    typeText.text = move.Set.Type.ToString();
  }

  public void UpdateCatchSelection(int selectedCatch)//update the hud with the selection 
  {
    for( int i=0; i<catchTexts.Count; ++i)
    {
      if (i == selectedCatch)
      {
         catchTexts[i].color = highlightedColor;
      }
      else
      {
        catchTexts[i].color = Color.black;
      }
    }
  }
}
