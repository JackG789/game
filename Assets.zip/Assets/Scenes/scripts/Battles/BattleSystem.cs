using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public enum BattelState{Start,ActionSelection,MoveSelection,PreformMove,Busy,TeamScreen,BattleOver,RunState,CatchSelection}//creating the selectable states when in combat


public class BattleSystem : MonoBehaviour
{
 [SerializeField] BattleFighter playerFighter;
 [SerializeField] BattleFighter enemyFighter;
 [SerializeField] BattleDialogBox dialogBox;
 [SerializeField] TeamScreen teamScreen;

 public event Action<bool> OnBattleOver;

 BattelState state;
 int currentAction;//players current action state
 int currentMove;//players current MOVE 
 int currentMember;
 int selectedCatch;

 int playerTurnCounter;
 int enemyTurnCounter;
int expYield;
int enemyLevel;
int expGain;

 FighterTeam playerTeam;
 FighterTeam trainerTeam;
 Fighter roamingFighter;

 public bool isTrainerBattle ;
 PlayerController player;
 TrainerController trainer;

 public void StartBattle(FighterTeam playerTeam, Fighter roamingFighter)
 {
      isTrainerBattle = false;
     this.playerTeam = playerTeam;
     this.roamingFighter = roamingFighter;
     
     StartCoroutine(SetupBattle());
 }


 
 public void StartTrainerBattle(FighterTeam playerTeam, FighterTeam trainerTeam)
 {
     this.playerTeam = playerTeam;
     this.trainerTeam = trainerTeam;

     isTrainerBattle = true;
    player = playerTeam.GetComponent<PlayerController>();
    trainer = trainerTeam.GetComponent<TrainerController>();
     StartCoroutine(SetupBattle());
 }

 public IEnumerator SetupBattle()
 {
     if(!isTrainerBattle)
     {
            //fighter battle
            playerFighter.Setup(playerTeam.GetHealthyFighter());//setting up the fighters information over to the battle hud 
            enemyFighter.Setup(roamingFighter);

            dialogBox.SetMoveNames(playerFighter.Fighter.Moves);


            yield return StartCoroutine(dialogBox.TypeDialog($"you have been challenged by a {enemyFighter.Fighter.Base.Name}"));//seting up the dialog box
        
            yield return new WaitForSeconds(1f);//adding a delay after the text appears to makesure the text is loaded in first 
     }
     else
     {
        enemyFighter.gameObject.SetActive(false);
        playerFighter.gameObject.SetActive(false);
         //trainer battle
        yield return StartCoroutine(dialogBox.TypeDialog($"you have been challenged by an opposing Trainer"));

        enemyFighter.gameObject.SetActive(true);
        var enemyMember = trainerTeam.GetHealthyFighter();
        enemyFighter.Setup(enemyMember);
        yield return StartCoroutine(dialogBox.TypeDialog($"you have been challenged by a trainers {enemyFighter.Fighter.Base.Name}"));//seting up the dialog box

        playerFighter.gameObject.SetActive(true);
        var playerMember = playerTeam.GetHealthyFighter();
        playerFighter.Setup(playerMember);
        yield return StartCoroutine(dialogBox.TypeDialog($"you have sent out {playerFighter.Fighter.Base.Name}"));//seting up the dialog box
        dialogBox.SetMoveNames(playerFighter.Fighter.Moves);

     }
    


    teamScreen.Init();
    ChoseFirstTurn();
 
 }


void ChoseFirstTurn()//speedcheck
{
    if(playerFighter.Fighter.Speed > enemyFighter.Fighter.Speed)
    {
        ActionSelection();
    }
    else
    {
        StartCoroutine(EnemyMove());
    }
}


public void runUpdateHp()
{
    teamScreen.SetTeamData(playerTeam.Fighters);
}





 void  BattleOver(bool won)
 {
     state = BattelState.BattleOver;

     OnBattleOver(won);
 }

 void OpenTeamScreen()
 {
     state = BattelState.TeamScreen;
     teamScreen.SetTeamData(playerTeam.Fighters);
     teamScreen.gameObject.SetActive(true);
 }

 void ActionSelection()
 {
     state= BattelState.ActionSelection;
     StartCoroutine(dialogBox.TypeDialog("select an action"));
     dialogBox.EnabelCatchSelect(false);
     dialogBox.EnabelActionSelect(true);
 }
/*void CatchSelection()
{
    state = BattelState.CatchSelection;
    dialogBox.EnabelActionSelect(false);
    dialogBox.EnabelDialogText(true);
    dialogBox.EnabelCatchSelect(true);
    StartCoroutine(HandleCatchSelection());
}*/


void MoveSelection()//setting the state to players move
{
    state = BattelState.MoveSelection;
    dialogBox.EnabelActionSelect(false);
    dialogBox.EnabelDialogText(false);
    dialogBox.EnabelMoveSelect(true);

}

IEnumerator PlayerMove()
{
   
    state =BattelState.PreformMove;
    
    var move = playerFighter.Fighter.Moves[currentMove];
    
    if(move.Set.CanBlock == false)
    {
        yield return RunMove(playerFighter,enemyFighter,move);

     //checking to see if the bttle state was changed by the run move or if it is still the same
    
        if(state == BattelState.PreformMove)
        {
        StartCoroutine(EnemyMove());
        }
    }
    else if(move.Set.CanBlock == true)
    {
        yield return dialogBox.TypeDialog($"{playerFighter.Fighter.Base.Name} attemts to block the enemys move");
        yield return new WaitForSeconds(0.5f);
        if(state == BattelState.PreformMove)
        {
            
            ChoseFirstTurn();
        }
    }
   
}


IEnumerator EnemyMove()
{
    
    state = BattelState.PreformMove;
  
    var move = enemyFighter.Fighter.GetEnemyMove(enemyFighter,playerFighter);
    
    if(move.Set.CanBlock == false)
    {
    
        yield return RunMove(enemyFighter,playerFighter, move);

        if(state == BattelState.PreformMove)
        {
         ActionSelection();
        }
    }
    else if(move.Set.CanBlock == true)
    {
        yield return dialogBox.TypeDialog($"{enemyFighter.Fighter.Base.Name} attempts to block your move");
        yield return new WaitForSeconds(0.5f);
        if(state == BattelState.PreformMove)
        {
            
            ChoseFirstTurn();
        }
    }
  
}

IEnumerator RunMove(BattleFighter sourceFighter, BattleFighter targetFighter, Move move)
{
    move.Energy--;
    yield return dialogBox.TypeDialog($"{sourceFighter.Fighter.Base.Name} used {move.Set.Name}");
  
        if(CheckIfMoveHit(move, sourceFighter, targetFighter)){
        sourceFighter.PlayAttackAnimation();
         yield return new WaitForSeconds(0.25f);

        targetFighter.PlayHitAnimation();
        var damageInfo = targetFighter.Fighter.TakeDamage(move, sourceFighter.Fighter);//applying damage to the enemy fighter
         yield return targetFighter.Hud.UpdateHP();
         yield return displayDamageDetails(damageInfo);


           if(damageInfo.Fainted )
              {
                 yield return dialogBox.TypeDialog($"{targetFighter.Fighter.Base.Name} Fainted ");
                 targetFighter.PlayFaintAnimation();

                 yield return new WaitForSeconds(1.5f);
            //if they faint logic needed here
                if(!targetFighter.IsPlayerFighter){
                 expYield = targetFighter.Fighter.Base.ExpYield;
                 enemyLevel = targetFighter.Fighter.Level;
                 expGain = Mathf.FloorToInt(expYield* enemyLevel)/7;

                playerFighter.Fighter.Exp+= expGain;
                yield return dialogBox.TypeDialog($"{sourceFighter.Fighter.Base.Name} gained {expGain} exp");
                 yield return new WaitForSeconds(1.5f);
                if (sourceFighter.Fighter.CheckForLevelUp())
                {
                
                yield return dialogBox.TypeDialog($"{sourceFighter.Fighter.Base.Name} grew to lvl {sourceFighter.Fighter.Level} exp");
                var newMove = sourceFighter.Fighter.GetLearnableMoveAtCurrentLevel();
                if(newMove != null)
                {
                    if(sourceFighter.Fighter.Moves.Count <4)
                    {

                    }
                    else
                    {

                    }
                }


                yield return new WaitForSeconds(1.5f);

                
                }
                }
                 CheckForBattleOver(targetFighter);
               }
         }
        else
        {
        yield return dialogBox.TypeDialog($"{targetFighter.Fighter.Base.Name}  missed! ");
        }
    
}



void CheckForBattleOver(BattleFighter faintedFighter)
{
   //yield return dialogBox.TypeDialog("madeit this far)");   
   // yield return new WaitForSeconds(0.25f);
    if(faintedFighter.IsPlayerFighter)
    {
        var nextFighter = playerTeam.GetHealthyFighter();

        if(nextFighter != null)
        {
            OpenTeamScreen();
        }
        else
        {
        BattleOver(false);
        }
    }
    else
    {
        if(!isTrainerBattle)
        {
            enemyFighter.Fighter.HP =enemyFighter.Fighter.MaxHp;
        playerTeam.AddFighter(enemyFighter.Fighter);
       BattleOver(true);
        }
        else
        {
           var nextFighter=trainerTeam.GetHealthyFighter();
           if(nextFighter!= null)
           {
               
               StartCoroutine(sendNextTrainerFighter(nextFighter));
           }
           else
           {
              
               BattleOver(true);
           }
        }

    }
}

bool CheckIfMoveHit(Move move, BattleFighter sourceFighter, BattleFighter targetFighter)
{
    float moveAccuracy = move.Set.Accuracy;
    return UnityEngine.Random.Range(1,101) <= moveAccuracy;
}

IEnumerator displayDamageDetails(DamageInfo damageInfo)
{
    if(damageInfo.Critical>1)
    {
        yield return dialogBox.TypeDialog("A critical Hit!!");
    }
    if(damageInfo.TypeEffect>1)
    {
        yield return dialogBox.TypeDialog("Super effective type move!");
    }
    else if(damageInfo.TypeEffect<1)
    {
        yield return dialogBox.TypeDialog("Non-effective type move!");
    }
}



public void HandleUpdate() //updating the gamestates 
{
    if (state == BattelState.ActionSelection)
    {
        StartCoroutine(HandleActionSelection());
    }
    else if ( state == BattelState.MoveSelection)
    {
        HandleMoveSelection();
    }
    else if ( state == BattelState.TeamScreen)
    {
        HandleTeamScreenSelction();
    }
    else if (state == BattelState.RunState)
    {
        ChoseFirstTurn();
    }
   // else if(state == BattelState.CatchSelection)
    //{/
     //   StartCoroutine(HandleCatchSelection());
    //}
  
}
/*IEnumerator HandleCatchSelection()
{
        yield return dialogBox.TypeDialog($"{enemyFighter.Fighter.Base.Name} would like to soul bond with you ");
        yield return new WaitForSeconds(1f);
        yield return dialogBox.TypeDialog("be carefull as you cannot detatch from your team later do you accept?");
        yield return new WaitForSeconds(1.5f);
        
        if(Input.GetKeyDown(KeyCode.DownArrow))
        {
        if(selectedCatch  == 0 )
        {
           selectedCatch+=1;
        }
        }
        else if(Input.GetKeyDown(KeyCode.UpArrow))
        {
        if(selectedCatch == 1)
        {
        selectedCatch -=1;
        }
        }
        dialogBox.UpdateCatchSelection(selectedCatch);

        if(Input.GetKeyDown(KeyCode.Z))
        {
         if(selectedCatch == 0)
         {
            playerTeam.AddFighter(enemyFighter.Fighter);
            
            } 
         
        }
}*/
IEnumerator HandleActionSelection()//selecting menu option
{
    if(Input.GetKeyDown(KeyCode.DownArrow))
    {
        if(currentAction < 2 )
        {
           currentAction+=2;
        }
    }
    else if(Input.GetKeyDown(KeyCode.UpArrow))
    {
        if(currentAction > 1)
        {
        currentAction -=2;
        }
    }
    else if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if(currentAction> 0)
            {  
                --currentAction ;
            }
        }
    else if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            if(currentAction<3)
            {  
                ++currentAction;
            }
        }
    dialogBox.UpdateActionSelection(currentAction);

    if(Input.GetKeyDown(KeyCode.Z))
    {
       if(currentAction == 0)
       {
            //fight
            MoveSelection();
       } 
       else if(currentAction == 1)
       {
           //bag 
       } 
        else if(currentAction == 2)
       {
           //team
           OpenTeamScreen();
       } 
        else if(currentAction == 3)
       {
           //run 
          
          yield return dialogBox.TypeDialog("you ran away successfully");
          BattleOver(true);
       } 
    }
 }

 void HandleMoveSelection() //selecting the move 
 {
     if(Input.GetKeyDown(KeyCode.RightArrow))
    {
        if(currentMove<playerFighter.Fighter.Moves.Count -1)
        {
           ++currentMove;
        }
    }
    else if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
        if(currentMove > 0)
        {
            --currentMove;
        }
    }
    else if(Input.GetKeyDown(KeyCode.DownArrow))
        {
            if(currentMove<playerFighter.Fighter.Moves.Count -2)
            {  
                currentMove +=2;
            }
        }
    else if(Input.GetKeyDown(KeyCode.UpArrow))
        {
            if(currentMove> 1)
            {  
                currentMove -=2;
            }
        }
        dialogBox.UpdateMoveSelection(currentMove, playerFighter.Fighter.Moves[currentMove]);
    
    if(Input.GetKeyDown(KeyCode.Z))//once move selected with z
    {
        dialogBox.EnabelMoveSelect(false);
        dialogBox.EnabelDialogText(true);

        StartCoroutine(PlayerMove());
    }
    else if(Input.GetKeyDown(KeyCode.X))
    {
        dialogBox.EnabelMoveSelect(false);
        dialogBox.EnabelDialogText(true);
        ActionSelection();
    }
 }

   public void HandleTeamScreenSelction() //selecting the next fighter to be sent out 
 {
      if(Input.GetKeyDown(KeyCode.RightArrow))
    {
        
        ++currentMember;
        
    }
    else if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
        
         --currentMember;
        
    }
    else if(Input.GetKeyDown(KeyCode.DownArrow))
        {
             
            currentMember +=2;
            
        }
    else if(Input.GetKeyDown(KeyCode.UpArrow))
        {
            
             currentMember -=2;
        
        }
    
    currentMember = Mathf.Clamp(currentMember,0,playerTeam.Fighters.Count-1);

    teamScreen.UpdateMemberSelection(currentMember);

    if(Input.GetKeyDown(KeyCode.Z))
    {
        var selectedMember = playerTeam.Fighters[currentMember];
        if(selectedMember.HP <=0)
        {
            teamScreen.SetMessageText("you are unable to send out a fainted fighter");
            return;
        }
        if(selectedMember == playerFighter.Fighter)
        {
            teamScreen.SetMessageText("that fighter is already out in the field");
        }
        else{
        teamScreen.gameObject.SetActive(false);
        state = BattelState.Busy;
        StartCoroutine(SwitchFighter(selectedMember));}
    }
    else if(Input.GetKeyDown(KeyCode.X))
    {
        teamScreen.gameObject.SetActive(false);
        ActionSelection();

    }
 }

 IEnumerator SwitchFighter(Fighter newFighter)//switching the fighter out with one from the party
 {
    bool currentFighterFainted = true;
    if(playerFighter.Fighter.HP > 0)
    {
    currentFighterFainted = false;
    yield return dialogBox.TypeDialog($"come back {playerFighter.Fighter.Base.Name}");
    playerFighter.PlayFaintAnimation();
    yield return new WaitForSeconds(1f);
    }
        
    playerFighter.Setup(newFighter);
    dialogBox.SetMoveNames(newFighter.Moves);

    yield return StartCoroutine(dialogBox.TypeDialog($"you have sent out {newFighter.Base.Name} to keep fighting!"));//seting up the dialog box
    
    if(currentFighterFainted)//if the latest sawp was a faint then do a speed check for turn
    {
        ChoseFirstTurn();
    }
    StartCoroutine(EnemyMove());

 }    

 IEnumerator sendNextTrainerFighter(Fighter nextFighter)
 {
    state =BattelState.Busy;

    enemyFighter.Setup(nextFighter);
    yield return StartCoroutine(dialogBox.TypeDialog($"{nextFighter.Base.Name} has been sent out by the trainer"));//seting up the dialog box
    yield return new WaitForSeconds(1f);
    state = BattelState.RunState;
 }
}
