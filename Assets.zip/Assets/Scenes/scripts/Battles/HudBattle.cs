using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class HudBattle : MonoBehaviour
{
 [SerializeField] Text playerFighterNameText;
 [SerializeField] Text playerFighterLvelText;
 [SerializeField] HealthBar HpBar;


  Fighter _fighter;//creating a local instance of the fighter object

 public void SetData(Fighter fighter)
 {
     _fighter = fighter;
     playerFighterNameText.text = fighter.Base.Name; //get the name of the fighter for the hud
      playerFighterLvelText.text = "Lvl " + _fighter.Level; // get the level of the fighter for the hud

     HpBar.SetHP((float)fighter.HP/fighter.MaxHp);//calculating the scale for the hp bar 
 }

 public IEnumerator UpdateHP()
 {
   
     yield return HpBar.SetHPSm((float)_fighter.HP/_fighter.MaxHp);//calculating the scale for the hp bar 
   
    
   
 }


}
