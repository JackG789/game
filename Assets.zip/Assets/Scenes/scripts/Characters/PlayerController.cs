using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed;
    public LayerMask solidLayer;
    public LayerMask shadowLayer;
    public LayerMask InteractableLayer;
    public LayerMask PortalLayer;
     
    public event Action OnEncountered;
    public  float currentX{get;set;}
    public float currentY{get;set;}
    private bool isMoving;
    private Vector2 input;
   // public Vector3 targetPos{get;set;}
    private Animator animator;
    
    private void Awake(){

        animator= GetComponent<Animator>();
    }
    
   
    // Update is called once per frame
    public void HandleUpdate()
    {
        if(!isMoving){
            
        input.x=Input.GetAxisRaw("Horizontal");
        input.y=Input.GetAxisRaw("Vertical");
        float currentX = transform.position.x;
        float currentY = transform.position.y;

        
            if(input != Vector2.zero){

                animator.SetFloat("moveX",input.x);
                animator.SetFloat("moveY",input.y);
                

                var targetPos = transform.position;
                targetPos.x += input.x;
                targetPos.y += input.y;

                if(isPassiable(targetPos))
                    StartCoroutine(Move(targetPos));
            }
        }
        animator.SetBool("isMoving",isMoving);
        if(Input.GetKeyDown(KeyCode.Z))
        {
                    Interaction();
                   // if (GetComponent<NPCController>(IsTP) = true)
                 //   {

                   // }
        }
    }

    void Interaction()
    {
        var faceingDir = new Vector3(animator.GetFloat("moveX"),animator.GetFloat("moveY"));//direction the player is facing when the interaction button is pressed
        var interactionPosition = transform.position + faceingDir;
        

        var collider = Physics2D.OverlapCircle(interactionPosition,0.3f,InteractableLayer);
        if(collider != null)
        {
            collider.GetComponent<Interactable>()?.Interact();
        }
     
    }


    IEnumerator Move(Vector3 targetPos)//moving and checking is the movement is effected by any other actions
    {
        isMoving = true;
        while((targetPos - transform.position).sqrMagnitude >Mathf.Epsilon){
            transform.position = Vector3.MoveTowards(transform.position,targetPos, moveSpeed * Time.deltaTime);
            yield return null;
        }
        transform.position = targetPos;
        isMoving = false;

        CheckforShadowEncounters();
    }

    private bool isPassiable(Vector3 targetPos)//wherether or not there is an object withing the area of the players path 
    {

        if(Physics2D.OverlapCircle(targetPos,0.06f,solidLayer|InteractableLayer) != null){
            return false;
        }
        return true;
    }


    private void CheckforShadowEncounters()//checking to see if in a shadow zone to enable random encounters
    {
         if(Physics2D.OverlapCircle(transform.position - new Vector3(0,0.3f),0.2f,shadowLayer) != null)
            {
               if( UnityEngine.Random.Range(1,101) <=10)
               {
                animator.SetBool("isMoving", false);
               
                OnEncountered();
                 
               }
             }
    }
    

}
