using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCController : MonoBehaviour, Interactable
{
    [SerializeField] Dialog dialog;
    [SerializeField] bool isTP;
    [SerializeField] bool isHealer;
    [SerializeField] float newXCord;
    [SerializeField] float newYCord;
    //FighterTeam Fighters;
   // FighterTeam playerTeam;
   // GameObject player;
    TeamMemberUI[] teamSlots;
    List<Fighter> fighters;
    Fighter _fighter;
 
    
   //Fighter Fighter;
   //Fighter playerFighter;

    public GameObject playerObject;
    //public GameObject BattleSystem;
     public float NewXCord{
          get{ return newXCord;}
       }
     public float NewYCord{
          get{ return newYCord;}
       }
    public bool IsTP{
        get{return isTP;}
    }

    public void Interact()

    {
      
        StartCoroutine(DialogManager.Instance.DisplayDialog(dialog));
        if(isTP == true){
            Vector3 pos = this.GetComponent<Transform>().position ;
            pos.x = newXCord;
            pos.y = newYCord;
            //Player.transform.position = new vector3(newXCord,newYcord,0);
            //pos.x = PlayerController.currentX;
            playerObject = GameObject.Find("Player");
            playerObject.transform.position = new Vector3(newXCord, newYCord, 0f);

        }
       
       if (isHealer == true)
        {

            
            
        }
    }

  

 

}
