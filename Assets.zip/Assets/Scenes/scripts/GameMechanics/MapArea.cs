using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapArea : MonoBehaviour
{
   [SerializeField] List<Fighter> roamingFighters;

   public Fighter GetRandFighter()
   {
       var roamingFighter = roamingFighters[Random.Range(0,roamingFighters.Count)];//creating the random fighter selected and putting it into the roaming fighter
       roamingFighter.Init(); 
       return roamingFighter;
   }
}
