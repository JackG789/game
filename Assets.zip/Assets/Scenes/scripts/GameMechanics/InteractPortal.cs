using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface InteractablePortal //an interface for all interactable objects inside the game
{
    void InteractPortal();
    
}