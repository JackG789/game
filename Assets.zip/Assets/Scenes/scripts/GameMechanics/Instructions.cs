using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instructions : MonoBehaviour
{
   
   public bool instructionsOpen = false ;
   public GameObject instructions;

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.M))
        {
            //debug.log("got here");
            if(!instructionsOpen)
            {
                ShowInstructions();
            }else 
            {
                hideInstructions();
            }
        }
    }

    public void ShowInstructions(){
        instructions.SetActive(true);
        instructionsOpen =true;
    }
    public void hideInstructions(){
        instructions.SetActive(false);
        instructionsOpen = false;
    }
}
