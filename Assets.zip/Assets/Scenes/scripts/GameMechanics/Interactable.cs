using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Interactable //an interface for all interactable objects inside the game
{
    void Interact();
    
}
