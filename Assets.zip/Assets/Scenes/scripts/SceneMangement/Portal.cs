using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField] int newXcord;
    [SerializeField] int newYcord;

   

   public void InteractPortal()
   {
     //  throw new System.NotImplementedException();
     Debug.Log("player entered the portal");
   }
  // public void Interact(){
   //    Debug.Log("player entered the portal interact");
   //}
}
